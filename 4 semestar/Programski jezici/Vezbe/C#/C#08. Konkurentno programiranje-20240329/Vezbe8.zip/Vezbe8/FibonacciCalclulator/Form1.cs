﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FibonacciCalclulator
{
    public partial class Form1 : Form
    {
        private int redniBrojZaRacunanje = 0;
        private int najvisiDostignutiProcenat = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnPokreniAsinh_Click(System.Object sender, System.EventArgs e)
        {
            // Brisanje natpisa u labeli za rezultat. 
            this.lblRezultat.Text = String.Empty;

            // Deaktiviranje kontrola dok se ne završi asinhrona operacija. 
            this.numRedniBroj.Enabled = false;
            this.btnPokreniAsinh.Enabled = false;

            // Aktiviranje dugmeta "Otkaži" dok se asinhrona operacija izvršava. 
            this.btnOtkaziAsinh.Enabled = true;

            // Uzimanje rednog broja člana Fibonačijevog niza koji se računa. 
            this.redniBrojZaRacunanje = (int)numRedniBroj.Value;

            // Resetuje se vrednost koja čuva dostignuti procenat za prikaz u
            // Progress Bar kontroli.
            najvisiDostignutiProcenat = 0;

            // Pokretanje asinhrone operacije.
            bgwRadnik.RunWorkerAsync(redniBrojZaRacunanje);
        }

        private void btnOtkaziAsinh_Click(System.Object sender, System.EventArgs e)
        {
            // Otkazivanje asinhrone operacije. 
            this.bgwRadnik.CancelAsync();

            // Deaktiviranje dugmeta "Otkaži". 
            btnOtkaziAsinh.Enabled = false;
        }

        // U ovom event handler-u se obavlja vremenski zahtevan posao. 
        private void bgwRadnik_DoWork(object sender, DoWorkEventArgs e)
        {
            // Ovo je BackgroundWorker koji je pokrenuo događaj. 
            BackgroundWorker worker = sender as BackgroundWorker;

            // U svojstvu e.Argument se prenosi argument koji je prosleđen 
            // prilikom poziva funkcije bgwRadnik.RunWorkerAsync. 
            // U e.Result se upisuje rezultat računanja traženog Fibonačijevog broja. 
            e.Result = IzracunajFibonaciBroj((int)e.Argument, worker, e);
        }

        // Ovaj event handler se izvršava kada BackgroundWorker završi vremenski
        // zahtevan posao.
        private void bgwRadnik_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Provera da li je možda došlo do neke greške prilikom izvršenja posla.
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            // Naredna provera - da li je možda metodom bgwRadnik.CancelAsync() 
            // otkazan posao. 
            else if (e.Cancelled)
            {
                lblRezultat.Text = "Canceled";
            }
            // U ovom slučaju asinhrona operacija je uspešno završena. 
            else
            {
                lblRezultat.Text = e.Result.ToString();
            }

            // Aktiviranje kontrola.
            this.numRedniBroj.Enabled = true;
            this.btnPokreniAsinh.Enabled = true;

            // Deaktiviranje dugmeta "Otkaži".
            btnOtkaziAsinh.Enabled = false;
        }

        // Ovaj event handler menja status Progress Bar-a kad se
        // promeni procenat odrađenog posla.
        private void bgwRadnik_ProgressChanged(object sender,
            ProgressChangedEventArgs e)
        {
            this.prbOdradjeniProcenat.Value = e.ProgressPercentage;
        }

        // Ova metoda izvršava vremenski zahtevan posao. Ovde je namerno iskorišćeno
        // sporo i zahtevno rekurzivno računanje zadatog Fibonačijevog broja da bi
        // se pokazalo kako rade BackgroundWorker i ProgressBar. Takođe, ovde se 
        // radi i ažuriranje procenata izvršenog posla. 
        long IzracunajFibonaciBroj(int n, BackgroundWorker worker, DoWorkEventArgs e)
        {
            // Argument mora biti >= 0 i <= 91. Fib(n), za n > 91, prekoračuje long podatak.
            if ((n < 0) || (n > 91))
            {
                throw new ArgumentException("Vrednost mora biti >= 0 i <= 91", "n");
            }

            long result = 0;

            // Poziv metode CancelAsync ne prekida direktno posao nego postavalja
            // CancellationPending na true. Stvarni prekid posla mora da se obavi
            // iz ove niti postavljanjem e.Cancel na true. 
            if (worker.CancellationPending)
            {
                e.Cancel = true;
            }
            else
            {
                if (n < 2)
                {
                    result = 1;
                }
                else
                {
                    result = IzracunajFibonaciBroj(n - 1, worker, e) +
                             IzracunajFibonaciBroj(n - 2, worker, e);
                }

                // Prikaz koliko procenata posla je završeno.
                int percentComplete =
                    (int)((float)n / (float)redniBrojZaRacunanje * 100);
                if (percentComplete > najvisiDostignutiProcenat)
                {
                    najvisiDostignutiProcenat = percentComplete;
                    worker.ReportProgress(percentComplete);
                }
            }
            return result;
        }
    }
}
