﻿
using System.ComponentModel;

namespace FibonacciCalclulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numRedniBroj = new System.Windows.Forms.NumericUpDown();
            this.btnPokreniAsinh = new System.Windows.Forms.Button();
            this.btnOtkaziAsinh = new System.Windows.Forms.Button();
            this.lblRezultat = new System.Windows.Forms.Label();
            this.prbOdradjeniProcenat = new System.Windows.Forms.ProgressBar();
            this.bgwRadnik = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.numRedniBroj)).BeginInit();
            this.SuspendLayout();
            // 
            // numRedniBroj
            // 
            this.numRedniBroj.Location = new System.Drawing.Point(16, 16);
            this.numRedniBroj.Name = "numRedniBroj";
            this.numRedniBroj.Size = new System.Drawing.Size(80, 22);
            this.numRedniBroj.TabIndex = 0;
            this.numRedniBroj.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnPokreniAsinh
            // 
            this.btnPokreniAsinh.Location = new System.Drawing.Point(16, 72);
            this.btnPokreniAsinh.Name = "btnPokreniAsinh";
            this.btnPokreniAsinh.Size = new System.Drawing.Size(143, 34);
            this.btnPokreniAsinh.TabIndex = 1;
            this.btnPokreniAsinh.Text = "Pokreni asinhrono";
            this.btnPokreniAsinh.Click += new System.EventHandler(this.btnPokreniAsinh_Click);
            // 
            // btnOtkaziAsinh
            // 
            this.btnOtkaziAsinh.Enabled = false;
            this.btnOtkaziAsinh.Location = new System.Drawing.Point(165, 72);
            this.btnOtkaziAsinh.Name = "btnOtkaziAsinh";
            this.btnOtkaziAsinh.Size = new System.Drawing.Size(148, 34);
            this.btnOtkaziAsinh.TabIndex = 2;
            this.btnOtkaziAsinh.Text = "Otkaži asinhrono";
            this.btnOtkaziAsinh.Click += new System.EventHandler(this.btnOtkaziAsinh_Click);
            // 
            // lblRezultat
            // 
            this.lblRezultat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRezultat.Location = new System.Drawing.Point(112, 16);
            this.lblRezultat.Name = "lblRezultat";
            this.lblRezultat.Size = new System.Drawing.Size(201, 23);
            this.lblRezultat.TabIndex = 3;
            this.lblRezultat.Text = "(nema rezultata)";
            this.lblRezultat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // prbOdradjeniProcenat
            // 
            this.prbOdradjeniProcenat.Location = new System.Drawing.Point(18, 48);
            this.prbOdradjeniProcenat.Name = "prbOdradjeniProcenat";
            this.prbOdradjeniProcenat.Size = new System.Drawing.Size(295, 8);
            this.prbOdradjeniProcenat.Step = 2;
            this.prbOdradjeniProcenat.TabIndex = 4;
            // 
            // bgwRadnik
            // 
            this.bgwRadnik.WorkerReportsProgress = true;
            this.bgwRadnik.WorkerSupportsCancellation = true;
            this.bgwRadnik.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwRadnik_DoWork);
            this.bgwRadnik.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgwRadnik_ProgressChanged);
            this.bgwRadnik.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwRadnik_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(325, 118);
            this.Controls.Add(this.prbOdradjeniProcenat);
            this.Controls.Add(this.lblRezultat);
            this.Controls.Add(this.btnOtkaziAsinh);
            this.Controls.Add(this.btnPokreniAsinh);
            this.Controls.Add(this.numRedniBroj);
            this.Name = "Form1";
            this.Text = "Fibonacci kalkulator";
            ((System.ComponentModel.ISupportInitialize)(this.numRedniBroj)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.NumericUpDown numRedniBroj;
        private System.Windows.Forms.Button btnPokreniAsinh;
        private System.Windows.Forms.Button btnOtkaziAsinh;
        private System.Windows.Forms.ProgressBar prbOdradjeniProcenat;
        private System.Windows.Forms.Label lblRezultat;
        private System.ComponentModel.BackgroundWorker bgwRadnik;

        #endregion
    }
}

