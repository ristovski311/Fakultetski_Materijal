﻿
namespace BackgroundWorkerPrimer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPokreniAsinh = new System.Windows.Forms.Button();
            this.btnOtkaziAsinh = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.bgwRadnik = new System.ComponentModel.BackgroundWorker();
            this.btnPokreni = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPokreniAsinh
            // 
            this.btnPokreniAsinh.Location = new System.Drawing.Point(11, 47);
            this.btnPokreniAsinh.Margin = new System.Windows.Forms.Padding(2);
            this.btnPokreniAsinh.Name = "btnPokreniAsinh";
            this.btnPokreniAsinh.Size = new System.Drawing.Size(130, 26);
            this.btnPokreniAsinh.TabIndex = 0;
            this.btnPokreniAsinh.Text = "Pokreni asinhrono";
            this.btnPokreniAsinh.UseVisualStyleBackColor = true;
            this.btnPokreniAsinh.Click += new System.EventHandler(this.btnPokreniAsinh_Click);
            // 
            // btnOtkaziAsinh
            // 
            this.btnOtkaziAsinh.Location = new System.Drawing.Point(11, 87);
            this.btnOtkaziAsinh.Margin = new System.Windows.Forms.Padding(2);
            this.btnOtkaziAsinh.Name = "btnOtkaziAsinh";
            this.btnOtkaziAsinh.Size = new System.Drawing.Size(130, 26);
            this.btnOtkaziAsinh.TabIndex = 1;
            this.btnOtkaziAsinh.Text = "Otkaži asinhrono";
            this.btnOtkaziAsinh.UseVisualStyleBackColor = true;
            this.btnOtkaziAsinh.Click += new System.EventHandler(this.btnOtkaziAsinh_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(11, 20);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(22, 13);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Text = "     ";
            // 
            // bgwRadnik
            // 
            this.bgwRadnik.WorkerReportsProgress = true;
            this.bgwRadnik.WorkerSupportsCancellation = true;
            this.bgwRadnik.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwRadnik_DoWork);
            this.bgwRadnik.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgwRadnik_ProgressChanged);
            this.bgwRadnik.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwRadnik_RunWorkerCompleted);
            // 
            // btnPokreni
            // 
            this.btnPokreni.Location = new System.Drawing.Point(164, 47);
            this.btnPokreni.Name = "btnPokreni";
            this.btnPokreni.Size = new System.Drawing.Size(75, 26);
            this.btnPokreni.TabIndex = 3;
            this.btnPokreni.Text = "Pokreni";
            this.btnPokreni.UseVisualStyleBackColor = true;
            this.btnPokreni.Click += new System.EventHandler(this.btnPokreni_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 141);
            this.Controls.Add(this.btnPokreni);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnOtkaziAsinh);
            this.Controls.Add(this.btnPokreniAsinh);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPokreniAsinh;
        private System.Windows.Forms.Button btnOtkaziAsinh;
        private System.Windows.Forms.Label lblStatus;
        private System.ComponentModel.BackgroundWorker bgwRadnik;
        private System.Windows.Forms.Button btnPokreni;
    }
}

