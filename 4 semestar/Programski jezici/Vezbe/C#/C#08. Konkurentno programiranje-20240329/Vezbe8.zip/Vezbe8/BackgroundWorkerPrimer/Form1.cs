﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackgroundWorkerPrimer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // U Properties pogledu za BackgroundWorker komponentu podešeno je
            // WorkerReportsProgress na true (da bi se aktivirao događaj ProgressChanged)
            // i WorkerSupportsCancelation na true (da bi se omogućilo prekidanje niti
            // klikom na dugme otkaži). 
        }


        private void btnPokreni_Click(object sender, EventArgs e)
        {
            // Pokretanje vremenski zahtevnog posla bez BackgroundWorker-a, 
            // u istoj niti koja pokreće i iscrtava formu, dovodi do toga 
            // da se forma "zamrzne". 
            for (int i = 1; i <= 10; i++)
            {
                // Vremenski zahtevan posao simuliramo uspavljivanjem niti
                // na zadati period.  
                System.Threading.Thread.Sleep(500);
                this.lblStatus.Text = i * 10 + "%";
            }
        }

        private void btnPokreniAsinh_Click(object sender, EventArgs e)
        {
            // Klik na dugme "Pokreni" asinhrono pokreće posao koji treba da obavi BackgroundWorker. 
            // Logika za pokretanje posebne niti je ugrađena u klasu BackgroundWorker i o 
            // tome ne treba da vodimo računa. Samo treba da se pozove metoda RunWorkerAsync(). 
            if (!bgwRadnik.IsBusy)
            {
                bgwRadnik.RunWorkerAsync();
            }
        }

        private void btnOtkaziAsinh_Click(object sender, EventArgs e)
        {
            // Klik na dugme "Otkaži" šalje signal BackgroundWorkeru da treba 
            // da prekine posao. Preciznije, postavlja njegov property CancellationPending
            // na true. Tu vrednost ispitujemo u _DoWork metodi. 
            if (bgwRadnik.WorkerSupportsCancellation)
            {
                bgwRadnik.CancelAsync();
            }
        }

        
        private void bgwRadnik_DoWork(object sender, DoWorkEventArgs e)
        {
            // U ovom event handleru se izvršava posao koji obavlja BackgroundWorker.
            BackgroundWorker radnik = sender as BackgroundWorker;
            for (int i = 1; i <= 10; i++)
            {
                if (radnik.CancellationPending)
                {
                    // Ako je korisnik prethodno kliknuo na dugme "Otkaži", ovde 
                    // postavljamo e.Cancel na true da bi se radnik isključio. 
                    e.Cancel = true;
                    break;
                }
                else
                {
                    // U suprotnom se obavlja vremenski zahtevni posao. Taj zahtevni
                    // posao ovde simuliramo uspavljivanjem niti na zadati period. 
                    System.Threading.Thread.Sleep(500);
                    radnik.ReportProgress(i * 10);
                    // Prethodna linija postavlja e.ProgressPercentage vrednost za 
                    // event handler bgwRadnik_ProgressChanged. Natpis na labeli 
                    // bi mogao da se postavlja i ovde narednom linijom, ali labela
                    // je kreirana u osnovnoj niti aplikacije, a glavni posao radnika 
                    // se pokreće u drugoj niti. Promene na kontrolama iz bilo koje 
                    // druge niti (osim one koja ih je kreirala) mogu da izazovu izuzetke. 
                    // Zbog toga naredna linija ne treba da se koristi. 
                    //this.lblStatus.Text = i * 10 + "%";
                }
            }
        }

        
        private void bgwRadnik_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // Ovaj event handler ažurira kontrolu koja prikazuje trenutni progres. 
            lblStatus.Text = (e.ProgressPercentage.ToString() + "%");
        }

        
        private void bgwRadnik_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Ovaj event handler se pokreće kada BackgroundWorker završi svoj posao
            // i prikazuje rezultat izvršenja.
            if (e.Cancelled)
                lblStatus.Text = "Otkazano!";
            else if (e.Error != null)
                lblStatus.Text = "Greška: " + e.Error.Message;
            else
                lblStatus.Text = "Završeno!";
        }

    }
}
