﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ProizvodjacPotrosacLock
{
	/// <summary>
	/// Kružni bafer koji treba da koriste i proizvođač i potrošač istovremeno 
	/// kroz različite niti.  
	/// </summary>
	class Bafer
    {
		// Niz celobrojnih podataka je deljivi resurs kome treba pristupati iz 
		// različitih niti. U ovom primeru se pristup deljivom resursu 
		// obezbeđuje korišćenjem monitora. 
		private int[] niz;
		private int pozicijaZaCitanje = 0, pozicijaZaUpis = 0, brojElemenata = 0;

		/// <summary>
		/// Konstruktor koji kreira niz celih brojeva zadate veličine. 
		/// </summary>
		/// <param name="velicina">Veličina niza. </param>
		public Bafer(int velicina)
		{
			niz = new int[velicina];
		}

		/// <summary>
		/// "Thread safe" implementacija metode koja upisuje novi broj 
		/// na narednu slobodnu poziciju u baferu. 
		/// </summary>
		/// <param name="vrednost">Broj koji se upisuje u bafer. </param>
		public void Upisi(int vrednost)
		{
			// Kritična sekcija koda koju ne treba da izvršava više niti istovremeno. 
			// Jezička konstrukcija lock(niz) se prevodi u Monitor.Enter(niz,...). 
			// Na kraju lock sekcije generiše se finally blok i u njemu 
			// Monitor.Enter(niz,...).
			lock (niz)
			{
				while (JePun)
				{
					// Sve dok je niz pun čeka se da druga nit pročita i oslobodi prostor. 
					Console.Out.WriteLine(Thread.CurrentThread.Name +
						": Čekam da upišem…");
					// Da while petlja ne bi aktivno trošila resurse procesora u toku čekanja,
					// trenutna nit se ovde pauzira. Može ponovo da se pokrene tek kad druga nit 
					// pozove Pulse metodu za isti objekat niz. 
					Monitor.Wait(niz);
				}
				// Upis. 
				niz[pozicijaZaUpis] = vrednost;
				// Ažuriranje pozicije za upis u kružnom baferu. 
				pozicijaZaUpis = (pozicijaZaUpis + 1) % niz.Length;
				brojElemenata++;
				// Metoda Pulse omogućava pokretanje druge niti koja je pauzirana Wait
				// metodom za isti objekat niz (ukoliko takva nit postoji). 
				Monitor.Pulse(niz);
				Console.Out.WriteLine(Thread.CurrentThread.Name + 
					": Upisano " + vrednost);
			}
		}

		/// <summary>
		/// "Thread safe" implementacija metode koja čita naredni dostupni podatak 
		/// iz bafera. 
		/// </summary>
		/// <returns>Podatak pročitan iz bafera. </returns>
		public int Procitaj()
		{
			// Kritična sekcija koda koju ne treba da izvršava više niti istovremeno. 
			// Jezička konstrukcija lock(niz) se prevodi u Monitor.Enter(niz,...). 
			// Na kraju lock sekcije generiše se finally blok i u njemu 
			// Monitor.Enter(niz,...).
			lock (niz)
			{
				while (JePrazan)
				{
					// Sve dok je niz prazan čeka se da druga nit upiše naredni podatak
					// za čitanje. 
					Console.Out.WriteLine(Thread.CurrentThread.Name + 
						": Čekam da pročitam…");
					// Da while petlja ne bi aktivno trošila resurse procesora u toku čekanja,
					// trenutna nit se ovde pauzira. Može ponovo da se pokrene tek kad druga nit 
					// pozove Pulse metodu za isti objekat niz. 
					Monitor.Wait(niz);
				}
				// Čitanje. 
				int retVal = niz[pozicijaZaCitanje];
				brojElemenata--;
				// Ažuriranje pozicije za čitanje u kružnom baferu. 
				pozicijaZaCitanje = (pozicijaZaCitanje + 1) % niz.Length;
				Console.Out.WriteLine(Thread.CurrentThread.Name + 
					": Pročitano " + retVal);
				// Metoda Pulse omogućava pokretanje druge niti koja je pauzirana Wait
				// metodom za isti objekat niz (ukoliko takva nit postoji). 
				Monitor.Pulse(niz);
				return retVal;
			}
		}

		/// <summary>
		/// Da li je bafer pun. 
		/// </summary>
		private bool JePun
		{
			get
			{
				return brojElemenata == niz.Length;
			}
		}

		/// <summary>
		/// Da li je bafer prazan. 
		/// </summary>
		private bool JePrazan
		{
			get
			{
				return brojElemenata == 0;
			}
		}
	}
}
