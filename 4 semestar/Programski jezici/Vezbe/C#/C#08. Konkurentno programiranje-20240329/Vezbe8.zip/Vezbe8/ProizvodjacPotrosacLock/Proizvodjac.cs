﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProizvodjacPotrosacLock
{
	/// <summary>
	/// Klasa Proizvođač koja upisuje podatke u bafer. 
	/// </summary>
	class Proizvodjac
    {
		private Bafer bafer;
		private int broj;

		/// <summary>
		/// Konsturktor. 
		/// </summary>
		/// <param name="bafer">Bafer u koji se upisuju podaci. </param>
		/// <param name="broj">Ukupan broj podataka koje treba upisati u bafer. </param>
		public Proizvodjac(Bafer bafer, int broj)
		{
			this.bafer = bafer;
			this.broj = broj;
		}

		/// <summary>
		/// Metoda koja generiše slučajne brojeve i upisuje ih u bafer. 
		/// </summary>
		public void Proizvedi()
		{
			Random rnd = new Random();
			for (int i = 0; i < broj; i++)
			{
				bafer.Upisi(rnd.Next(1, 100));
			}
		}
	}
}
