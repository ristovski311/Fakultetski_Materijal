﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProizvodjacPotrosacSemafor
{
    /// <summary>
    /// Klasa Potrošač koja čita podatke iz bafera. 
    /// </summary>
    class Potrosac
    {
        private Bafer bafer;
        private int brojElemenata;
        // Sinhronizacija niti se u ovom primeru obavlja pomoću 2 semafora. 
        // I proizvođač i potrošač čuvaju instance ova 2 semafora. 
        private Semaphore semaforCitanje;
        private Semaphore semaforUpis;

        /// <summary>
        /// Konstruktor. 
        /// </summary>
        /// <param name="bafer">Bafer u koji se upisuju podaci. </param>
        /// <param name="brojElemenata">Ukupan broj podataka koje treba upisati u bafer. </param>
        /// <param name="semaforCitanje">Semafor koji treba da pauzira čitanje ako nema
        /// dostupnih elemenata za čitanje. </param>
        /// <param name="semaforUpis">Semafor koji treba da pauzira upis ako nema 
        /// slobodnih mesta za upis. </param>
        public Potrosac(Bafer bafer, int brojElemenata, Semaphore semaforCitanje,
            Semaphore semaforUpis)
        {
            this.bafer = bafer;
            this.brojElemenata = brojElemenata;
            this.semaforCitanje = semaforCitanje;
            this.semaforUpis = semaforUpis;
        }

        /// <summary>
        /// Metoda koja čita naredni dostupni podatak iz bafera. 
        /// </summary>
        public void Potrosi()
        {
            for (int i = 0; i < brojElemenata; i++)
            {
                // Brojač semafora za čitanje u svakom trenutku ima vrednost jednaku 
                // broju nepročitanih elemenata u baferu. Pre upisa se taj brojač
                // dekrementira metodom WaitOne().
                semaforCitanje.WaitOne();
                bafer.Procitaj();
                // Brojač semafora za upis u svakom trenutku ima vrednost jednaku 
                // broju praznih mesta u baferu. Posle čitanja se taj brojač dekrementira
                // metodom Release(). 
                semaforUpis.Release();
            }
        }
    }
}
