﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProizvodjacPotrosacSemafor
{
	/// <summary>
	/// Klasa Proizvođač koja upisuje podatke u bafer. 
	/// </summary>
	class Proizvodjac
    {
		private Bafer bafer;
		private int brojElemenata;
		// Sinhronizacija niti se u ovom primeru obavlja pomoću 2 semafora. 
		// I proizvođač i potrošač čuvaju instance ova 2 semafora. 
		private Semaphore semaforCitanje;
		private Semaphore semaforUpis;

		/// <summary>
		/// Konstruktor. 
		/// </summary>
		/// <param name="bafer">Bafer u koji se upisuju podaci. </param>
		/// <param name="brojElemenata">Ukupan broj podataka koje treba upisati u bafer. </param>
		/// <param name="semaforCitanje">Semafor koji treba da pauzira čitanje ako nema
		/// dostupnih elemenata za čitanje. </param>
		/// <param name="semaforUpis">Semafor koji treba da pauzira upis ako nema 
		/// slobodnih mesta za upis. </param>
		public Proizvodjac(Bafer bafer, int brojElemenata, Semaphore semaforCitanje, 
			Semaphore semaforUpis)
		{
			this.bafer = bafer;
			this.brojElemenata = brojElemenata;
			this.semaforCitanje = semaforCitanje;
			this.semaforUpis = semaforUpis;
		}

		/// <summary>
		/// Metoda koja generiše slučajne brojeve i upisuje ih u bafer. 
		/// </summary>
		public void Proizvedi()
		{
			Random rnd = new Random();
			for (int i = 0; i < brojElemenata; i++)
			{
				// Brojač semafora za upis u svakom trenutku ima vrednost jednaku 
				// broju praznih mesta u baferu. Pre upisa se taj brojač dekrementira
				// metodom WaitOne(). 
				semaforUpis.WaitOne();
				bafer.Upisi(rnd.Next(1, 100));
				// Brojač semafora za čitanje u svakom trenutku ima vrednost jednaku 
				// broju nepročitanih elemenata u baferu. Posle upisa se taj brojač
				// inkrementira metodom Release().
				semaforCitanje.Release();
			}
		}
	}
}
