﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ProizvodjacPotrosacSemafor
{
    /// <summary>
    /// Kružni bafer koji treba da koriste i proizvođač i potrošač istovremeno 
    /// kroz različite niti. Ovde bafer nema logiku za sprečavanje konflikata 
    /// u višenitnom okruženju. O tome se vodi računa na strani proizvođača i 
    /// potrošača korišćenjem mehanizma semafora. 
    /// </summary>

    class Bafer
    {
        // Niz celobrojnih podataka je deljivi resurs kome treba pristupati iz 
        // različitih niti. 
        private int[] niz;
        private int pozicijaZaCitanje = 0, pozicijaZaUpis = 0, brojElemenata = 0;

        /// <summary>
        /// Konstruktor koji kreira niz celih brojeva zadate veličine. 
        /// </summary>
        /// <param name="velicina">Veličina niza. </param>
        public Bafer(int velicina)
        {
            niz = new int[velicina];
        }

        /// <summary>
        /// Jednostavna implementacija metode (nije "thread safe") koja upisuje novi 
        /// broj na narednu slobodnu poziciju u baferu. 
        /// </summary>
        /// <param name="vrednost">Broj koji se upisuje u bafer. </param>
        public void Upisi(int vrednost)
        {
            // Upis. 
            niz[pozicijaZaUpis] = vrednost;
            // Ažuriranje pozicije za upis u kružnom baferu. 
            pozicijaZaUpis = (pozicijaZaUpis + 1) % niz.Length;
            brojElemenata++;
            Console.Out.WriteLine(Thread.CurrentThread.Name +
                ": Upisano " + vrednost);
        }

        /// <summary>
		/// Jednostavna implementacija metode (nije "thread safe") koja čita naredni 
        /// dostupni podatak iz bafera. 
		/// </summary>
		/// <returns>Podatak pročitan iz bafera. </returns>
        public int Procitaj()
        {
            // Čitanje. 
            int procitanaVrednost = niz[pozicijaZaCitanje];
            brojElemenata--;
            // Ažuriranje pozicije za čitanje u kružnom baferu. 
            pozicijaZaCitanje = (pozicijaZaCitanje + 1) % niz.Length;
            Console.Out.WriteLine(Thread.CurrentThread.Name +
                ": Pročitano " + procitanaVrednost);
            return procitanaVrednost;
        }

        /// <summary>
		/// Da li je bafer pun. 
		/// </summary>
		private bool JePun
        {
            get
            {
                return brojElemenata == niz.Length;
            }
        }

        /// <summary>
        /// Da li je bafer prazan. 
        /// </summary>
        private bool JePrazan
        {
            get
            {
                return brojElemenata == 0;
            }
        }
    }
}