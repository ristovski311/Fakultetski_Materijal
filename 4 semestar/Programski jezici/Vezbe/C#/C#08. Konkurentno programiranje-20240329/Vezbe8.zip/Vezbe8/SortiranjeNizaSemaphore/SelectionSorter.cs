﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class SelectionSorter
    {
        private Array array;
        private Semaphore semSorted; // Brojač ovog semafora će čuvati trenutni broj sortiranih elemenata.
        public SelectionSorter(Array array)
        {
            this.array = array;
            this.semSorted = new Semaphore(0, int.MaxValue);
        }

        public Semaphore SemSorted
        {
            get
            {
                return this.semSorted;
            }
        }

        public void Sort()
        {
            int length = array.Length;
            for (int i = 0; i < length - 1; i++)
            {
                int iMin = i;
                for (int j = i + 1; j < length; j++)
                {
                    if (array[j] < array[iMin])
                        iMin = j;
                }
                if (iMin != i)
                {
                    double tmp = array[iMin];
                    array[iMin] = array[i];
                    array[i] = tmp;
                }
                // Za svaki sortirani element se povećava brojač u semaforu. 
                semSorted.Release();
            }
            // Petlja ide do dužine niza - 1 pa se ovde povećava brojač za poslednji element niza. 
            semSorted.Release();
        }
    }
}
