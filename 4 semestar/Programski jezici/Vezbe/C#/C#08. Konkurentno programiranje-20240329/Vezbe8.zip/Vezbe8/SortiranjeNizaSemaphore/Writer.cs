﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Writer
    {
		private Array array;
		private Semaphore semMerged;

		public Writer(Array array, Semaphore semMerged)
		{
			this.array = array;
			this.semMerged = semMerged;
		}

		public void Write()
		{
			for (int i = 0; i < array.Length; i++)
			{
				semMerged.WaitOne();
				Console.Out.WriteLine(array[i]);
			}
		}
	}
}
