﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class MergeSorter
    {
		private Array left, right, merged;
		private Semaphore semMerged; // Brojač ovog semafora će čuvati trenutni broj sortiranih elemenata.

		private Semaphore leftSemSorted, rightSemSorted; 
		// Semafori iz SelectionSortera iz levog odnosno desnog podniza. 
		// Njihovi brojači će pokazivati koliko MergeSorter može da pročita elemenata iz levog i desnog podniza. 

		public MergeSorter(Array left, Array right, 
			Semaphore leftSemSorted, Semaphore rightSemSorted)
		{
			this.left = left;
			this.leftSemSorted = leftSemSorted;
			this.right = right;
			this.rightSemSorted = rightSemSorted;
			this.merged = new Array(left.Length + right.Length);
			this.semMerged = new Semaphore(0, int.MaxValue);
		}

		public Semaphore SemMerged
        {
			get
            {
				return this.semMerged;
            }
        }

		public void Merge()
		{
			int i = 0, j = 0, k = 0;
			while (i < left.Length && j < right.Length)
			{
				// Da bismo pročitali element sa indeksom i semafor mora da ima i+1 sortiranih.
				leftSemSorted.WaitOne();
				double leftEl = left[i];
				// Da bismo pročitali element sa indeksom j semafor mora da ima j+1 sortiranih. 
			    rightSemSorted.WaitOne();
				double rightEl = right[j];
				if (leftEl < rightEl)
				{
					merged[k++] = leftEl;
					i++;
					// Oslobađamo semafor za niz iz kog nismo iskoristili element. 
					rightSemSorted.Release();
				}
				else
				{
					merged[k++] = rightEl;
					j++;
					// Oslobađamo semafor za niz iz kog nismo iskoristili element. 
					leftSemSorted.Release();
				}
				// Još jedan element je spreman za čitanje.
				this.semMerged.Release();
			}
			while (i < left.Length)
			{
				merged[k++] = left[i++];
				// Još jedan element je spreman za čitanje.
				this.semMerged.Release();
			}
			while (j < right.Length)
			{
				merged[k++] = right[j++];
				// Još jedan element je spreman za čitanje.
				this.semMerged.Release();
			}
		}

		public Array Merged
		{
			get
			{
				return this.merged;
			}
		}
	}
}
