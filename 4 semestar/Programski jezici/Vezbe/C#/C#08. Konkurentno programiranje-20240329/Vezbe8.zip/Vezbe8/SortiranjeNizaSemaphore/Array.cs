﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Array
    {
		private double[] elements;

		public Array()
		{
			this.elements = new double[] { 3, 4, 1, 8, 6, 2, 9, 7, 5 };
		}

		public Array(int length)
		{
			this.elements = new double[length];
		}

		public int Length
		{
			get
			{
				return this.elements.Length;
			}
		}

		public double this[int i]
        {
			get
            {
				return this.elements[i];
			}
            set
            {
				this.elements[i] = value;
            }
        }

		public Array[] Split()
		{
			int boundary = this.elements.Length / 2;
			Array left = new Array(boundary);
			for (int i = 0; i < boundary; i++)
			{
				left.elements[i] = this.elements[i];
			}
			Array right = new Array(this.elements.Length - boundary);
			for (int i = boundary; i < this.elements.Length; i++)
			{
				right.elements[i - boundary] = this.elements[i];
			}
			return new Array[] { left, right };
		}
	}
}
