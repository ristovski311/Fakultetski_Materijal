﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Program
    {
        static void Main(string[] args)
        {
			Array start = new Array();
			Array[] split = start.Split();

			SelectionSorter leftSorter = new SelectionSorter(split[0]);
			SelectionSorter rightSorter = new SelectionSorter(split[1]);
			MergeSorter mergeSorter = new MergeSorter(split[0], split[1]);
			Writer writer = new Writer(mergeSorter.Merged);

			Thread t1 = new Thread(writer.Write);
			t1.Name = "Writer";
			Thread t2 = new Thread(mergeSorter.Merge);
			t2.Name = "Merge sorter";
			Thread t3 = new Thread(leftSorter.Sort);
			t3.Name = "Left sorter";
			Thread t4 = new Thread(rightSorter.Sort);
			t4.Name = "Right sorter";

			t1.Start();
			t2.Start();
			t3.Start();
			t4.Start();
			
			t1.Join();
			t2.Join();
			t3.Join();
			t4.Join();
		}
    }
}
