﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Array
    {
		private double[] elements;
		private int numSorted;

		public Array()
		{
			this.numSorted = 0;
			this.elements = new double[] { 3, 4, 1, 8, 6, 2, 9, 7, 5 };
		}

		public Array(int length)
		{
			this.numSorted = 0;
			this.elements = new double[length];
		}

		public int Length
		{
			get
			{
				return this.elements.Length;
			}
		}

		public double this[int i]
        {
			get
            {
				return this.elements[i];
			}
            set
            {
				this.elements[i] = value;
            }
        }

		public Array[] Split()
		{
			int boundary = this.elements.Length / 2;
			Array left = new Array(boundary);
			for (int i = 0; i < boundary; i++)
			{
				left.elements[i] = this.elements[i];
			}
			Array right = new Array(this.elements.Length - boundary);
			for (int i = boundary; i < this.elements.Length; i++)
			{
				right.elements[i - boundary] = this.elements[i];
			}
			return new Array[] { left, right };
		}

		public double GetSorted(int position)
		{
			lock (elements)
			{
				while (position >= this.numSorted)
				{
					Console.Out.WriteLine(Thread.CurrentThread.Name 
						+ ": čekam sledeći sortirani…");
					Monitor.Wait(elements);
				}
				Console.Out.WriteLine(Thread.CurrentThread.Name 
					+ ": pročitano elements[" + position + "] = " + this.elements[position]);
				return this.elements[position];
			}
		}

		public void SetSorted(int position)
		{
			lock (elements)
			{
				this.numSorted = position + 1;
				Console.Out.WriteLine(Thread.CurrentThread.Name 
					+ ": sortirano elements[" + position + "] = " + this.elements[position]);
				Monitor.Pulse(elements);
			}
		}
	}
}
