﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace ProizvodjacPotrosacMonitor
{
    class Program
    {
        // Veličina bafera. 
        public const int VELICINA_BAFERA = 5;
        // Broj podataka koje treba upisati i pročitati iz bafera. Namerno je taj 
        // broj veći od veličine bafera da bi se testirala situacija kad proizvođač 
        // više nema slobodnih mesta u baferu za upis. 
        public const int BROJ_ELEMENATA = 10;
        static void Main(string[] args)
        {
            Bafer buffer = new Bafer(VELICINA_BAFERA);
            Proizvodjac p = new Proizvodjac(buffer, BROJ_ELEMENATA);
            Potrosac c = new Potrosac(buffer, BROJ_ELEMENATA);

            // Kreiranje posebnih niti za proizvođača i potrošača. 
            Thread proizvodjac = new Thread(p.Proizvedi);
            proizvodjac.Name = "1.Proizvođač";
            Thread potrosac = new Thread(c.Potrosi);
            potrosac.Name = "2.Potrošač";
            // Pokretanje tih niti. 
            proizvodjac.Start();
            potrosac.Start();
            // Join metoda pauzira Main nit dok se nit za koju je Join pozvana ne završi. 
            proizvodjac.Join();
            potrosac.Join();
        }
    }
}
