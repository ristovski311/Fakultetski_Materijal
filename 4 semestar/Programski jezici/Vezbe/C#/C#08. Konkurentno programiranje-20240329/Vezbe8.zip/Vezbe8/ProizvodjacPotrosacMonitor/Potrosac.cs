﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProizvodjacPotrosacMonitor
{
	/// <summary>
	/// Klasa Potrošač koja čita podatke iz bafera. 
	/// </summary>
    class Potrosac
    {
		private Bafer bafer;
		private int broj;

		/// <summary>
		/// Konsturktor. 
		/// </summary>
		/// <param name="bafer">Bafer iz kog se čitaju podaci. </param>
		/// <param name="broj">Ukupan broj podataka koje treba pročitati iz bafera. </param>
		public Potrosac(Bafer bafer, int broj)
		{
			this.bafer = bafer;
			this.broj = broj;
		}

		/// <summary>
		/// Metoda koja čita naredni dostupni podatak iz bafera. 
		/// </summary>
		public void Potrosi()
		{
			for (int i = 0; i < broj; i++)
			{
				bafer.Procitaj();
			}
		}
	}
}
