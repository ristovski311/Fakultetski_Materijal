﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Array
    {
		private double[] elements;
		private int numSorted;

		public Array()
		{
			this.numSorted = 0;
			this.elements = new double[] { 3, 4, 1, 8, 6, 2, 9, 7, 5 };
		}

		public Array(int numElements, bool generateMembers)
        {
			this.numSorted = 0;
			this.elements = new double[numElements];
			if (generateMembers)
			{
				Random rnd = new Random();
				for (int i = 0; i < numElements; i++)
					this.elements[i] = rnd.Next(1, numElements);
			}
		}

		public Array(int numElements) : this(numElements, false)
        {
        }

		public int Length
		{
			get
			{
				return this.elements.Length;
			}
		}

		public double this[int i]
        {
			get
            {
				return this.elements[i];
			}
            set
            {
				this.elements[i] = value;
            }
        }

		public Array[] Split()
		{
			int boundary = this.elements.Length / 2;
			Array left = new Array(boundary);
			for (int i = 0; i < boundary; i++)
			{
				left.elements[i] = this.elements[i];
			}
			Array right = new Array(this.elements.Length - boundary);
			for (int i = boundary; i < this.elements.Length; i++)
			{
				right.elements[i - boundary] = this.elements[i];
			}
			return new Array[] { left, right };
		}

		public Array[] Split(int parts)
		{
			Array[] split = new Array[parts];
			int start = 0, end;
			for (int subArrayIndex = 1; subArrayIndex <= parts; subArrayIndex++)
            {
				end = (this.elements.Length * subArrayIndex) / parts;

				Array subArray = new Array(end - start);
				for (int i = 0; i < subArray.Length; i++)
				{
					subArray.elements[i] = this.elements[start + i];
				}
				start = end; // Element na indeksu end se ne uključuje u tekući niz,
							 // nego se prenosi kao start za naredni niz. 
				split[subArrayIndex - 1] = subArray;
			}
			return split;
		}

		public double GetSorted(int position)
		{
			lock (elements)
			{
				while (position >= this.numSorted)
				{
					Monitor.Wait(elements);
				}
				return this.elements[position];
			}
		}

		public void SetSorted(int position)
		{
			lock (elements)
			{
				this.numSorted = position + 1;
				Monitor.Pulse(elements);
			}
		}
	}
}
