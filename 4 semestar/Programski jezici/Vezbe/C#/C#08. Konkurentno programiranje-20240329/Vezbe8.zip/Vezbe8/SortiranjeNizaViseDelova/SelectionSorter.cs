﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class SelectionSorter
    {
        private Array array;
        public SelectionSorter(Array array)
        {
            this.array = array;
        }

        public void Sort()
        {
            int length = array.Length;
            for (int i = 0; i < length - 1; i++)
            {
                int iMin = i;
                for (int j = i + 1; j < length; j++)
                {
                    if (array[j] < array[iMin])
                        iMin = j;
                }
                if (iMin != i)
                {
                    double tmp = array[iMin];
                    array[iMin] = array[i];
                    array[i] = tmp;
                }
                array.SetSorted(i);
            }
            array.SetSorted(length - 1);
        }

        public void SortSingleThread()
        {
            int length = array.Length;
            for (int i = 0; i < length - 1; i++)
            {
                int iMin = i;
                for (int j = i + 1; j < length; j++)
                {
                    if (array[j] < array[iMin])
                        iMin = j;
                }
                if (iMin != i)
                {
                    double tmp = array[iMin];
                    array[iMin] = array[i];
                    array[i] = tmp;
                }
            }
        }

    }
}
