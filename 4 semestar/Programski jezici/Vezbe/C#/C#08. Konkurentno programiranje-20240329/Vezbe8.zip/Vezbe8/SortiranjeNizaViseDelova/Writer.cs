﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Writer
    {
		private Array array;

		public Writer(Array array)
		{
			this.array = array;
		}

		public void Write()
		{
			for (int i = 0; i < array.Length; i++)
			{
				Console.Out.WriteLine(array.GetSorted(i));
			}
		}

		public void WriteMax()
        {
			Console.Out.WriteLine(array.GetSorted(array.Length - 1));
		}
	}
}
