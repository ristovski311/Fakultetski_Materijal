﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class Program
    {
        static void Main(string[] args)
        {
			Array startArray = new Array(100000, true);

			DateTime startTime = DateTime.Now;
			Array[] split = startArray.Split(4);

			SelectionSorter sorter1 = new SelectionSorter(split[0]);
			SelectionSorter sorter2 = new SelectionSorter(split[1]);
			SelectionSorter sorter3 = new SelectionSorter(split[2]);
			SelectionSorter sorter4 = new SelectionSorter(split[3]);

			MergeSorter mergeSorter12 = new MergeSorter(split[0], split[1]);
			MergeSorter mergeSorter34 = new MergeSorter(split[2], split[3]);
			MergeSorter mergeSorter1234 = new MergeSorter(mergeSorter12.Merged, mergeSorter34.Merged);

			Writer writer = new Writer(mergeSorter1234.Merged);

			Thread t1 = new Thread(sorter1.Sort);
			Thread t2 = new Thread(sorter2.Sort);
			Thread t3 = new Thread(sorter3.Sort);
			Thread t4 = new Thread(sorter4.Sort);
			Thread t5 = new Thread(mergeSorter12.Merge);
			Thread t6 = new Thread(mergeSorter34.Merge);
			Thread t7 = new Thread(mergeSorter1234.Merge);

			t1.Start();
			t2.Start();
			t3.Start();
			t4.Start();
			t5.Start();
			t6.Start();
			t7.Start();

			t1.Join();
            t2.Join();
            t3.Join();
            t4.Join();
			t5.Join();
			t6.Join();
			t7.Join();
			
			TimeSpan elapsedTime = DateTime.Now - startTime;
			writer.WriteMax();
			Console.Out.WriteLine("Višenitno sortiranje završeno za "
				+ elapsedTime.TotalMilliseconds + " milisekundi. ");


			startTime = DateTime.Now;
			split = startArray.Split(4);

			sorter1 = new SelectionSorter(split[0]);
			sorter2 = new SelectionSorter(split[1]);
			sorter3 = new SelectionSorter(split[2]);
			sorter4 = new SelectionSorter(split[3]);

			mergeSorter12 = new MergeSorter(split[0], split[1]);
			mergeSorter34 = new MergeSorter(split[2], split[3]);
			mergeSorter1234 = new MergeSorter(mergeSorter12.Merged, mergeSorter34.Merged);

			writer = new Writer(mergeSorter1234.Merged);

			sorter1.SortSingleThread();
			sorter2.SortSingleThread();
			sorter3.SortSingleThread();
			sorter4.SortSingleThread();
			mergeSorter12.MergeSingleThread();
			mergeSorter34.MergeSingleThread();
			mergeSorter1234.MergeSingleThread();

			elapsedTime = DateTime.Now - startTime;
			Console.Out.WriteLine(mergeSorter1234.Merged[
				mergeSorter1234.Merged.Length - 1]);
			Console.Out.WriteLine("Jednonitni merge sort završen za "
				+ elapsedTime.TotalMilliseconds + " milisekundi. ");

			startTime = DateTime.Now;
			SelectionSorter simpleSorter = new SelectionSorter(startArray);
			simpleSorter.SortSingleThread();
			elapsedTime = DateTime.Now - startTime;
			Console.Out.WriteLine(startArray[startArray.Length - 1]);
			Console.Out.WriteLine("Jednonitni selection sort završen za "
				+ elapsedTime.TotalMilliseconds + " milisekundi. ");
		}
    }
}
