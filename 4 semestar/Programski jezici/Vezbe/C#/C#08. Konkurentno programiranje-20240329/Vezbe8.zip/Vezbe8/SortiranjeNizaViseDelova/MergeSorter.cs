﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortiranjeNizaLock
{
    class MergeSorter
    {
		private Array left, right, merged;

		public MergeSorter(Array left, Array right)
		{
			this.left = left;
			this.right = right;
			this.merged = new Array(left.Length + right.Length);
		}

		public void Merge()
		{
			int i = 0, j = 0, k = 0;
			while (i < left.Length && j < right.Length)
			{
				double leftEl = left.GetSorted(i);
				double rightEl = right.GetSorted(j);
				if (leftEl < rightEl)
				{
					merged[k] = leftEl;
					i++;
				}
				else
				{
					merged[k] = rightEl;
					j++;
				}
				merged.SetSorted(k++);
			}
			while (i < left.Length)
			{
				merged[k] = left.GetSorted(i++);
				merged.SetSorted(k++);
			}
			while (j < right.Length)
			{
				merged[k] = right.GetSorted(j++);
				merged.SetSorted(k++);
			}
		}

		public void MergeSingleThread()
		{
			int i = 0, j = 0, k = 0;
			while (i < left.Length && j < right.Length)
			{
				double leftEl = left[i];
				double rightEl = right[j];
				if (leftEl < rightEl)
				{
					merged[k++] = leftEl;
					i++;
				}
				else
				{
					merged[k++] = rightEl;
					j++;
				}
			}
			while (i < left.Length)
			{
				merged[k++] = left[i++];
			}
			while (j < right.Length)
			{
				merged[k++] = right[j++];
			}
		}

		public Array Merged
		{
			get
			{
				return this.merged;
			}
		}
	}
}
