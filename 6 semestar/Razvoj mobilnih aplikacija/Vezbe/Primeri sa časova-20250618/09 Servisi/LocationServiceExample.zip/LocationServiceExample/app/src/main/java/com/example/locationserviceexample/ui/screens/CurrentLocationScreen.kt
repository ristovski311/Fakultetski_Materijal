package com.example.locationserviceexample.ui.screens

import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun CurrentLocationScreen(lat: Double, lng: Double) {
    Surface {
        Text(text = "Current latitude: $lat, longitude: $lng")
    }
}
