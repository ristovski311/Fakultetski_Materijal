package com.example.locationserviceexample

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.work.OneTimeWorkRequest
import com.example.locationserviceexample.services.LocationTrackerService
import com.example.locationserviceexample.ui.screens.CurrentLocationScreen
import com.example.locationserviceexample.ui.theme.LocationServiceExampleTheme


class MainActivity : ComponentActivity() {
    var i: Intent? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
            ),
            0
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestBGLocationPermission()
        }

        setContent {
            LocationServiceExampleTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CurrentLocationScreen(lat = 0.0, lng = 0.0 )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        i = Intent(applicationContext, LocationTrackerService::class.java)
        startForegroundService(i)
    }

    override fun onStop() {
        super.onStop()
        stopService(i)
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    fun requestBGLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ),
            0
        )
    }
}
