package com.example.roomwordsample.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.roomwordsample.ui.WordViewModel

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun WordListScreen(viewModel: WordViewModel, navigateToAddWord: () -> Unit) {
    val list = viewModel.allWords.collectAsState(initial = listOf())
    
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = navigateToAddWord,
                content = {
                    Icon(Icons.Filled.Add, "Floating action button.")
                }
            )
        }
    ) {
        LazyColumn {
            items(list.value) { item ->
                Card(modifier = Modifier.padding(12.dp)) {
                    Text(text = "${item.id} ${item.word}", modifier = Modifier.padding(24.dp).fillMaxWidth())
                }
            }
        }
    }
}