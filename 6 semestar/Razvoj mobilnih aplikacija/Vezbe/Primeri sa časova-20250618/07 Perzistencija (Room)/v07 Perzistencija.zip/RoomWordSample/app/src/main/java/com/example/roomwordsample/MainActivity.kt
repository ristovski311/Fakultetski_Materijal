package com.example.roomwordsample

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.roomwordsample.ui.WordViewModel
import com.example.roomwordsample.ui.WordViewModelFactory
import com.example.roomwordsample.ui.screens.AddWordScreen
import com.example.roomwordsample.ui.screens.WordListScreen
import com.example.roomwordsample.ui.theme.RoomWordSampleTheme

class MainActivity : ComponentActivity() {
    private val wordViewModel: WordViewModel by viewModels {
        WordViewModelFactory((application as WordsApplication).repository)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RoomWordSampleTheme {
                // A surface container using the 'background' color from the theme
                WordApp(viewModel = wordViewModel)
            }
        }
    }
}

@Composable
fun WordApp(viewModel: WordViewModel) {
    val navController = rememberNavController()
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        NavHost(navController = navController, startDestination = Screens.WordList.name) {
            composable(Screens.WordList.name) {
                WordListScreen(
                    viewModel = viewModel,
                    navigateToAddWord = { navController.navigate(Screens.AddWord.name) })
            }
            composable(Screens.AddWord.name) {
                AddWordScreen(viewModel = viewModel, navigateBack = { navController.popBackStack() })
            }
        }

    }
}

enum class Screens {
    WordList,
    AddWord
}