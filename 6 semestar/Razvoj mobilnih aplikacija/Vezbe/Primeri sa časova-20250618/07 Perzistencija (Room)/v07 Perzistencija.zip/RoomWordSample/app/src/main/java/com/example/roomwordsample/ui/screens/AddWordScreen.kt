package com.example.roomwordsample.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.roomwordsample.data.entities.Word
import com.example.roomwordsample.ui.WordViewModel

@Composable
fun AddWordScreen(viewModel: WordViewModel, navigateBack: () -> Unit) {
    var input by rememberSaveable {
        mutableStateOf("")
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        TextField(value = input, onValueChange = { input = it }, modifier = Modifier.padding(36.dp))
        Button(onClick = {
            viewModel.insert(Word(0, input))
            navigateBack()
        }) {
            Text(text = "Insert")
        }
    }
}