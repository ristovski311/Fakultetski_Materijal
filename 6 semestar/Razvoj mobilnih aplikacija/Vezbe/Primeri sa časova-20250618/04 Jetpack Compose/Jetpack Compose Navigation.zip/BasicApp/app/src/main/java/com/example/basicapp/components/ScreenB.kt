package com.example.basicapp.components

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.items

@Composable
fun ScreenB(list: List<String>, modifier: Modifier = Modifier, navigateToA: () -> Unit) {
    Surface {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Button(onClick = navigateToA) {
                Text(text = "Back to Screen A")
            }
            LazyColumn {// kreira samo ono sto se nalazi na ekranu, za razliku od Column
                items(list) {item -> // sintaksa za iteriranje kroz kolekciju elemenata za crtanje
                    Card(modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)) {
                        Text(text = item, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(24.dp))
                    }
                }
            }
        }
    }
}