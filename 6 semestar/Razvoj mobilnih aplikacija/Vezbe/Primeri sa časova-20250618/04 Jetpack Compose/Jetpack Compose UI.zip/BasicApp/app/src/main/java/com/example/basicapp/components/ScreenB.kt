package com.example.basicapp.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun ScreenB(list: List<String>, modifier: Modifier = Modifier) {
    for (item in list) {
        Text(text = item, color = MaterialTheme.colorScheme.primary)
    }

}