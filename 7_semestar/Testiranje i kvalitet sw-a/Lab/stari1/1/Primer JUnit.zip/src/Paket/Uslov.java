package Paket;

public class Uslov {
	public static boolean VrednostUslova() {
		return true;
	}
}
