package Paket;

public class Pocetna {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		var kalkulator = new Kalkulator();
		System.out.println(kalkulator.Dodaj(10, 20));
	}
}
