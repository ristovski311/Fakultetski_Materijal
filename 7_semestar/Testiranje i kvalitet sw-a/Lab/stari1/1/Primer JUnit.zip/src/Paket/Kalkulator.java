package Paket;

public class Kalkulator {
	public int Dodaj(int broj1, int broj2) {
		//throw new java.lang.RuntimeException("Exception");
		return broj1 + broj2;
	}
	
	public boolean Neparni(int broj) {
		// return broj % 2 == 1;
		// Ova linija iznad vraća grešku!
		// return Math.abs(broj % 2) == 1;
		// Jedna od ispravki, ali može i 
		return broj % 2 != 0;
	}
	
	public int[] vratiNiz() {
		int[] array = new int[] {
			10, 20, 30	
		};
		return array;
	}
}
