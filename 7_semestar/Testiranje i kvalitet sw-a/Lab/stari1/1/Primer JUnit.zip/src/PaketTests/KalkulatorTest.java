package PaketTests;

import Paket.*;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;

// @TestClassOrder
// Za order klasa

@DisplayName("Klasa za testiranje")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class KalkulatorTest {

	static Kalkulator kalkulator;
	
	@BeforeAll
	public static void BeforeClass() {
		System.out.println("Before All");
		kalkulator = new Kalkulator();
	}
	
	@BeforeEach
	public void Before() {
		System.out.println("Before Each");
	}
	
	// @Disabled ako hoćemo da ga isključimo
	@Timeout(1000)
	@DisplayName("Prvi test")
	@Test
	@Order(2)
	public void test() {
		System.out.println("Test metoda");
		assertThrows(java.lang.RuntimeException.class, () -> {
			kalkulator.Dodaj(10, 20);
		});
		//assertEquals(30, );
	}
	
	@DisplayName("Drugi test")
	@ParameterizedTest
	@ValueSource(ints = {1, 3, 5, -3, 15, Integer.MAX_VALUE}) // six numbers
	@Order(1)
	public void test2(int number) {
		System.out.println("Test2 metoda");
		assertTrue(kalkulator.Neparni(number));
	}
	
	@Timeout(value = 1, unit = TimeUnit.MICROSECONDS)
	@DisplayName("Treći test")
	@Order(4)
	@Test
	public void test3() {
		System.out.println("Test3 metoda");
		String br = String.valueOf(kalkulator.Dodaj(100, 500));
		assertAll("String provera",
                () -> assertTrue(br.startsWith("6")),
                () -> assertTrue(br.endsWith("0"))
            );
	}
	
	@DisplayName("Četvrti test")
	@Order(3)
	@Test
	// @DisabledOnOs(OS.WINDOWS)
	// Da bi zabranili test na Windows-u
	public void test4() {
		System.out.println("Test4 metoda");
		assertTimeout(Duration.ofSeconds(2), () -> {
			kalkulator.Neparni(100);
        });
	}
	
	@DisplayName("Peti test")
	@Order(5)
	@Test
	@DisabledOnOs(OS.LINUX)
	@DisabledIf("Paket.Uslov#VrednostUslova")
	public void test5() {
		System.out.println("Test5 metoda");
	}
	
	@DisplayName("Test niza")
	@Test
	public void test6() {
		System.out.println("Test 6");
		int[] niz = new int[] {
				10, 20, 30
		};
		
		var vratio = kalkulator.vratiNiz();
		
		assertArrayEquals(niz, vratio, "Nisu isti nizovi");
	}
	
	@AfterEach
	public void After() {
		System.out.println("After Each");
	}
	
	@AfterAll
	public static void AfterClass() {
		System.out.println("After All");
	}

}
